const fs = require('fs');

// Function to read database
function readDatabase() {
    const data = fs.readFileSync('database.txt', 'utf8');
    return JSON.parse(data);
}

// Function to search a record by ID
function searchRecord(id) {
    const records = readDatabase();
    return records.find(record => record.id === id);
}

// Function to add a new record
function addRecord(newRecord) {
    const records = readDatabase();
    records.push(newRecord);
    fs.writeFileSync('database.txt', JSON.stringify(records, null, 2));
}

// Example Usage
console.log(searchRecord(1)); // Search for ID 1

addRecord({ id: 4, name: "Carl", age: 22 }); // Add a new record
console.log("New record added!");
