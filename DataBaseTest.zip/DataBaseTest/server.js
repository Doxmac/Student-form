const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware to parse JSON requests
app.use(express.json());
app.use(express.static(__dirname)); // Serve static files

// Handle POST request to add names
app.post('/add-name', (req, res) => {
    const { name } = req.body;
    if (!name) {
        return res.json({ success: false, message: "No name provided!" });
    }

    // Append name to the text file
    fs.appendFile("database.txt", name + "\n", (err) => {
        if (err) {
            return res.json({ success: false, message: "Error saving name!" });
        }
        res.json({ success: true, message: "Name saved!" });
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
